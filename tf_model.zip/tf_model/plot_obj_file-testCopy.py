# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 10:33:05 2022

@author: gurut
"""

from apscheduler.schedulers.background import BackgroundScheduler
sched = BackgroundScheduler()


import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'    

import tensorflow as tf


PATH_TO_LABELS = r"label_map.pbtxt"
import time

import visualization_utils as viz_utils

PATH_TO_SAVED_MODEL = r"SAVED_MODEL_TF2\\saved_model\\"

print('Loading model...', end='')
start_time = time.time()

# Load saved model and build the detection function
detect_fn = tf.saved_model.load(os.getcwd()+"\\"+PATH_TO_SAVED_MODEL)

end_time = time.time()
elapsed_time = end_time - start_time
print('Done! Took {} seconds'.format(elapsed_time))

category_index = {1: {'id': 1, 'name': 'deer'},
 2: {'id': 2, 'name': 'nilgai'},
 3: {'id': 3, 'name': 'redfox'},
 4: {'id': 4, 'name': 'gaur'},
 5: {'id': 5, 'name': 'chinkara'},
 6: {'id': 6, 'name': 'humans'},
 7: {'id': 7, 'name': 'indian grey mongoose'},
 8: {'id': 8, 'name': 'indian peafowl'},
 9: {'id': 9, 'name': 'leopard'},
 10: {'id': 10, 'name': 'samll indian civet'},
 11: {'id': 11, 'name': 'sloth bear'},
 12: {'id': 12, 'name': 'wild boar'},
 13: {'id': 13, 'name': 'sambar deer'},
 14: {'id': 14, 'name': 'grey langur'},
 15: {'id': 15, 'name': 'red wattled lapuring'},
 16: {'id': 16, 'name': 'peafowl'}}



import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')   # Suppress Matplotlib warnings




class tfModelImages: 
    def detection(imagePath, threshold, savePath = None, save = False):
        # self.savePath = savePath
        # self.imagePath = imagePath
        
        # self.threshold = threshold
        
        print(imagePath, threshold, end='')
    
        image_np = np.array(Image.open(imagePath))
    
        input_tensor = tf.convert_to_tensor(image_np)
        
        input_tensor = input_tensor[tf.newaxis, ...]
    
        detections = detect_fn(input_tensor)
    
        num_detections = int(detections.pop('num_detections'))
        detections = {key: value[0, :num_detections].numpy()
                       for key, value in detections.items()}
        detections['num_detections'] = num_detections
    
        detections['detection_classes'] = detections['detection_classes'].astype(np.int64)
    
    
        viz_utils.visualize_boxes_and_labels_on_image_array(
              image_np,
              detections['detection_boxes'],
              detections['detection_classes'],
              detections['detection_scores'],
              category_index,
              use_normalized_coordinates=True,
              max_boxes_to_draw=200,
              min_score_thresh = threshold,
              agnostic_mode=False)
        
        classes = np.squeeze(detections['detection_classes'])
        confidence = np.squeeze(detections['detection_scores'])
        if save == True:
            plt.imshow(image_np)
            
            if not os.path.exists(savePath):
                os.makedirs(savePath)
            j = imagePath.split('/')  
            
            j = j[-1][:-4] + "NEW" + ".jpg" 
            plt.savefig(savePath + j)
            
            print("\n\nIMAGE SAVED at ", savePath + j)
        
        temp = []
        for (clss, cnf) in zip(classes,confidence):
            if cnf > float(threshold):
                temp.append((clss, cnf))
                
        classNames = [category_index[x[0]]['name'] for x in temp]
        
        imgPathImage = savePath + j[-1]
        
        return classNames, len(classNames), image_np, j
    
path = "inputImages/" 
OutPath = "output/" 
alldata = os.listdir(path)

def test():

    if len(os.listdir(path)) >=1:
        
        for name in range(0, len(os.listdir(path))):
            imgpath = os.path.join(path,alldata[name])
            print(imgpath)
            tfModelImages.detection(imagePath = imgpath, threshold = 0.5, savePath=OutPath, save = True)
    else:
        pass
        
        

if __name__ == '__main__':
    scheduler = BackgroundScheduler()
    scheduler.add_job(test, 'interval', seconds=1, id='my_job_id')    
    
    #scheduler.add_job(ipScheduleCheck, 'interval', seconds=4)
    
    scheduler.start()











    
    